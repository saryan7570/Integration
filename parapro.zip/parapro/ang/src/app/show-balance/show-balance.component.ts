import { Component, OnInit, Injector, RootRenderer, Injectable } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']

})
@Injectable({
  providedIn:'root'
})

export class ShowBalanceComponent implements OnInit {
   
  balance:number;
  constructor(private customerService : CustomerServiceService) { }

  ngOnInit() {
  }
  showBalance(accnum): number
  {
  this.customerService.showBalance(accnum).subscribe(data=>{
  this.balance=data;
  console.log(this.balance);  
})
return this.balance;
  }
}
